package com.example.rapidstrikeapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ViewCarry extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.carrymod_page);
    }
}